from machine import Pin, ADC
import time

# === Pin Configuration ===
segments = [Pin(i, Pin.OUT) for i in range(8)]  # a to dp
digits = [Pin(i, Pin.OUT) for i in range(8, 12)]  # digit1 to digit4
adc_input = ADC(Pin(26))  # Analog input
button = Pin(16, Pin.IN, Pin.PULL_UP)  # Pushbutton with pull-up resistor

# === Segment Encoding  ===
segment_encoding = [
    0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78,  # 0-7
    0x00, 0x10, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E, 0x7F  # 8-9, A-F, blank
]

def decode_segments(pattern):
    return [(pattern >> bit) & 1 for bit in range(7)]

last_press = 0
voltage_mv = 0
button_triggered = False

# === Interrupt Handler with proper debounce ===
def on_press(pin):
    global button_triggered, last_press
    now = time.ticks_ms()

    # Check if button is still pressed (to avoid light touches)
    if button.value() == 0 and time.ticks_diff(now, last_press) > 300:
        button_triggered = True
        last_press = now

# === Measure Voltage ===
def measure_voltage():
    global voltage_mv
    raw = adc_input.read_u16()
    voltage_mv = int((raw * 3.3 / 65535) * 1000)
    print("Voltage:", voltage_mv, "mV")

# === Display Single Digit ===
def show(digit_pos, digit_val):
    for d in digits:
        d.value(0)  # Turn off all digits

    bits = decode_segments(segment_encoding[digit_val])
    for i in range(7):
        segments[i].value(bits[i])

    # Only show decimal point for the leftmost digit (digit 1 = index 3)
    segments[7].value(0 if digit_pos == 3 else 1)  # dp is ON only at digit 1

    digits[digit_pos].value(1)  # Enable current digit

# === Show Voltage on Display ===
def show_voltage(value_mv):
    digits_list = [0, 0, 0, 0]
    value = value_mv

    for i in range(4):
        digits_list[3 - i] = value % 10
        value //= 10

    for _ in range(40):
        for i in range(4):
            show(i, digits_list[3 - i])
            time.sleep_ms(3)

# === Main Function ===
def main():
    global button_triggered
    while True:
        if button_triggered:
            button_triggered = False
            measure_voltage()
        show_voltage(voltage_mv)

# === Attach Interrupt and Run ===
button.irq(trigger=Pin.IRQ_FALLING, handler=on_press)

if __name__ == '__main__':
    main()

